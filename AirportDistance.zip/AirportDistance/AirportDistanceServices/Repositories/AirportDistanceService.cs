﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AirportDistance.Models;

namespace AirportDistance.Services
{
    public class AirportDistanceService : IAirportDistanceService
    {
        public async Task<double> GetDistanceBetweenLocation(string sourceLocation, string destinationLocation)
        {
            var address = "Stavanger, Norway";

            //var source = GetLatLongFromAddress(sourceLocation);
            //var destination = GetLatLongFromAddress(destinationLocation);
         
            //return LatLongDistanceTo(source.Item2, source.Item3, destination.Item2, destination.Item3);
            return (LatLongDistanceTo(13.0827, 80.2707, 19.0760, 72.8777));
        }

        public double LatLongDistanceTo(double lat1, double lon1, double lat2, double lon2, char unit = 'K')
        {
            double rlat1 = Math.PI * lat1 / 180;
            double rlat2 = Math.PI * lat2 / 180;
            double theta = lon1 - lon2;
            double rtheta = Math.PI * theta / 180;
            double dist =
                Math.Sin(rlat1) * Math.Sin(rlat2) + Math.Cos(rlat1) *
                Math.Cos(rlat2) * Math.Cos(rtheta);
            dist = Math.Acos(dist);
            dist = dist * 180 / Math.PI;
            dist = dist * 60 * 1.1515;

            switch (unit)
            {
                case 'K': //Kilometers -> default
                    return dist * 1.609344;
                case 'N': //Nautical Miles 
                    return dist * 0.8684;
                case 'M': //Miles
                    return dist;
            }

            return (dist);
        }

        public async Task<double> FindDistance(Location startLocation, Location destinationLocation)
        {
            var totalDistance = HaversineDistance(startLocation, destinationLocation);
            return totalDistance;
        }

        /// <summary>
        /// HaversineDistance
        /// </summary>
        /// <param name="location1"></param>
        /// <param name="location2"></param>
        /// <returns></returns>
        public double HaversineDistance(Location location1, Location location2)
        {
            var earthRadius = 6371; // Radius of the Earth in kilometers
            var latitudeDifference = DegreesToRadians(location2.Latitude - location1.Latitude);
            var longitudeDifference = DegreesToRadians(location2.Longitude - location1.Longitude);
            var a = Math.Sin(latitudeDifference / 2) * Math.Sin(latitudeDifference / 2) +
            Math.Cos(DegreesToRadians(location1.Latitude)) * Math.Cos(DegreesToRadians(location2.Latitude)) *
            Math.Sin(longitudeDifference / 2) * Math.Sin(longitudeDifference / 2);
            var c = 2 * Math.Atan2(Math.Sqrt(a), Math.Sqrt(1 - a));
            var distance = earthRadius * c;
            return distance;
        }

        /// <summary>
        /// DegreesToRadians
        /// </summary>
        /// <param name="degrees"></param>
        /// <returns></returns>
        public double DegreesToRadians(double degrees)
        {
            return degrees * (Math.PI / 180);
        }

        /// <summary>
        /// RadiansToDegree
        /// </summary>
        /// <param name="degrees"></param>
        /// <returns></returns>
        public double RadiansToDegree(double degrees)
        {
            return degrees * (180 / Math.PI);
        }

    }
}
