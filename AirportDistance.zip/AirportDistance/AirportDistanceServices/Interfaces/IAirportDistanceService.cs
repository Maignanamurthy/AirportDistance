﻿using AirportDistance.Models;

namespace AirportDistance.Services
{
    public interface IAirportDistanceService
    {
        Task<double> GetDistanceBetweenLocation(string sourceLocation, string destinationLocation);

        double LatLongDistanceTo(double lat1, double lon1, double lat2, double lon2, char unit = 'K');

        Task<double> FindDistance(Location startLocation, Location destinationLocation);

        double HaversineDistance(Location location1, Location location2);

        double DegreesToRadians(double degrees);

        double RadiansToDegree(double degrees);
    }
}
