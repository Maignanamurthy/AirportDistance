﻿namespace AirportDistanceServices
{
    public class Class1
    {

    }
}