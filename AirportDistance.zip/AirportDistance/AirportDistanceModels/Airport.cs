﻿namespace AirportDistance.Models
{
    /// <summary>
    /// Airport
    /// </summary>
    public class Airport
    {
        public string IATACODE { get; set; }

        public string AIRPORTNAME { get; set; }

        public string CITY { get; set; }

        public string STATE { get; set; }

        public string COUNTRY { get; set; }

        public double LAT { get; set; }

        public double LONG { get; set; }

    }
}
