﻿namespace AirportDistance.Models
{
    /// <summary>
    /// Location
    /// </summary>
    public class Location
    {
        public double Latitude { get; set; }
        public double Longitude { get; set; }

        /// <summary>
        /// Location
        /// </summary>
        /// <param name="latitude"></param>
        /// <param name="longitude"></param>
        public Location(double latitude, double longitude)
        {
            Latitude = latitude;
            Longitude = longitude;
        }
    }
}
