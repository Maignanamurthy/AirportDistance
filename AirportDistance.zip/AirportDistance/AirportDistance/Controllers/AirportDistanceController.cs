﻿using AirportDistance.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Runtime;


namespace AirportDistance.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class AirportDistanceController : ControllerBase
    {
        private readonly IAirportDistanceService _airportDistanceService;

        public AirportDistanceController(IAirportDistanceService airportDistanceService)
        {
            _airportDistanceService = airportDistanceService;
        }

        [HttpGet(Name = "GetAirportDistance")]
        public async Task<IActionResult> GetEventsSummaryByRecentDays([FromQuery] string sourceLocation, string destinationLocation)
        {
            //return null;
            return Ok(await _airportDistanceService.GetDistanceBetweenLocation(sourceLocation, destinationLocation));
        }
    }
}
